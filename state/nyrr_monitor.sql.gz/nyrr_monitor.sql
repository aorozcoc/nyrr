--
-- PostgreSQL database dump
--

\restrict nIhINWGGylMqrcRCxtld05JpTxcFLzne93Jn7mA9lu3qNvN2wAeJiRZ6Z014rKt

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: nyrr_monitor; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA nyrr_monitor;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_state; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.app_state (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: availability_transitions; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.availability_transitions (
    transition_id uuid NOT NULL,
    shift_id text NOT NULL,
    previous_classification text,
    new_classification text NOT NULL,
    detected_at timestamp with time zone NOT NULL,
    run_id uuid NOT NULL,
    from_version integer NOT NULL,
    reason_codes text[] DEFAULT '{}'::text[] NOT NULL,
    alert_generated boolean DEFAULT false NOT NULL,
    alert_snapshot jsonb,
    CONSTRAINT transitions_new_chk CHECK ((new_classification = ANY (ARRAY['AVAILABLE_VERIFIED'::text, 'UNAVAILABLE'::text, 'UNVERIFIED'::text]))),
    CONSTRAINT transitions_prev_chk CHECK (((previous_classification IS NULL) OR (previous_classification = ANY (ARRAY['AVAILABLE_VERIFIED'::text, 'UNAVAILABLE'::text, 'UNVERIFIED'::text]))))
);


--
-- Name: email_test_cycles; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.email_test_cycles (
    cycle_id uuid NOT NULL,
    test_id uuid NOT NULL,
    cycle_number integer NOT NULL,
    expected_at timestamp with time zone NOT NULL,
    executed_at timestamp with time zone NOT NULL,
    trigger text NOT NULL,
    CONSTRAINT email_test_cycles_cycle_number_check CHECK (((cycle_number >= 1) AND (cycle_number <= 4)))
);


--
-- Name: email_test_deliveries; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.email_test_deliveries (
    delivery_id uuid NOT NULL,
    cycle_id uuid NOT NULL,
    recipient_email text NOT NULL,
    delivery_status text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    requested_at timestamp with time zone,
    responded_at timestamp with time zone,
    provider_message_id text,
    last_error text,
    CONSTRAINT email_test_deliveries_status_chk CHECK ((delivery_status = ANY (ARRAY['PENDING'::text, 'SENDING'::text, 'ACCEPTED'::text, 'FAILED_RETRYABLE'::text, 'FAILED_PERMANENT'::text])))
);


--
-- Name: email_test_runs; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.email_test_runs (
    test_id uuid NOT NULL,
    activated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text NOT NULL,
    authorized_by text NOT NULL,
    total_cycles integer DEFAULT 4 NOT NULL,
    CONSTRAINT email_test_status_chk CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'COMPLETED'::text, 'EXPIRED'::text, 'ABORTED'::text])))
);


--
-- Name: events; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.events (
    event_id text NOT NULL,
    event_name text NOT NULL,
    event_date date NOT NULL,
    location text,
    event_url text NOT NULL,
    event_end_date date,
    event_status text,
    event_tags text[] DEFAULT '{}'::text[] NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_incidents; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.health_incidents (
    incident_id uuid NOT NULL,
    incident_type text NOT NULL,
    severity text NOT NULL,
    opened_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone NOT NULL,
    resolved_at timestamp with time zone,
    alert_sent_at timestamp with time zone,
    details text,
    CONSTRAINT health_severity_chk CHECK ((severity = ANY (ARRAY['DEGRADED'::text, 'CRITICAL'::text, 'WARNING'::text])))
);


--
-- Name: locks; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.locks (
    lock_name text NOT NULL,
    holder text NOT NULL,
    acquired_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: monitoring_runs; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.monitoring_runs (
    run_id uuid NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text NOT NULL,
    events_checked integer DEFAULT 0 NOT NULL,
    shifts_checked integer DEFAULT 0 NOT NULL,
    verified_openings integer DEFAULT 0 NOT NULL,
    unverified_shifts integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    error_summary text,
    trigger text,
    scheduled_for timestamp with time zone,
    full_sweep boolean DEFAULT false NOT NULL,
    requests_made integer DEFAULT 0 NOT NULL,
    source_failures integer DEFAULT 0 NOT NULL,
    parser_errors integer DEFAULT 0 NOT NULL,
    transitions_created integer DEFAULT 0 NOT NULL,
    notifications_created integer DEFAULT 0 NOT NULL,
    CONSTRAINT monitoring_runs_status_chk CHECK ((status = ANY (ARRAY['RUNNING'::text, 'SUCCESS'::text, 'PARTIAL'::text, 'FAILED'::text, 'SKIPPED_LOCKED'::text, 'NOT_AUTHORIZED'::text, 'EXPIRED'::text])))
);


--
-- Name: notifications; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.notifications (
    notification_id uuid NOT NULL,
    transition_id uuid NOT NULL,
    recipient_email text NOT NULL,
    delivery_status text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp with time zone,
    provider_message_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text NOT NULL,
    accepted_at timestamp with time zone,
    last_error text,
    needs_review boolean DEFAULT false NOT NULL,
    CONSTRAINT notifications_status_chk CHECK ((delivery_status = ANY (ARRAY['PENDING'::text, 'SENDING'::text, 'ACCEPTED'::text, 'FAILED_RETRYABLE'::text, 'FAILED_PERMANENT'::text, 'SUPPRESSED'::text])))
);


--
-- Name: schema_migrations; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.schema_migrations (
    version text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shifts; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.shifts (
    shift_id text NOT NULL,
    event_id text NOT NULL,
    role_name text NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    is_medical boolean,
    plus_one_2026 boolean,
    availability_status text NOT NULL,
    classification text NOT NULL,
    registration_url text,
    source_url text NOT NULL,
    verified_at timestamp with time zone,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    is_restricted boolean,
    reason_codes text[] DEFAULT '{}'::text[] NOT NULL,
    state_version integer DEFAULT 0 NOT NULL,
    alert_armed boolean DEFAULT true NOT NULL,
    last_observed_run_id uuid,
    last_alerted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT shifts_available_needs_url_chk CHECK (((classification <> 'AVAILABLE_VERIFIED'::text) OR ((registration_url IS NOT NULL) AND (verified_at IS NOT NULL) AND (is_medical = false) AND (plus_one_2026 = true)))),
    CONSTRAINT shifts_classification_chk CHECK ((classification = ANY (ARRAY['AVAILABLE_VERIFIED'::text, 'UNAVAILABLE'::text, 'UNVERIFIED'::text])))
);


--
-- Data for Name: app_state; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.app_state (key, value, updated_at) FROM stdin;
\.


--
-- Data for Name: availability_transitions; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.availability_transitions (transition_id, shift_id, previous_classification, new_classification, detected_at, run_id, from_version, reason_codes, alert_generated, alert_snapshot) FROM stdin;
\.


--
-- Data for Name: email_test_cycles; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.email_test_cycles (cycle_id, test_id, cycle_number, expected_at, executed_at, trigger) FROM stdin;
\.


--
-- Data for Name: email_test_deliveries; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.email_test_deliveries (delivery_id, cycle_id, recipient_email, delivery_status, attempt_count, requested_at, responded_at, provider_message_id, last_error) FROM stdin;
\.


--
-- Data for Name: email_test_runs; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.email_test_runs (test_id, activated_at, expires_at, completed_at, status, authorized_by, total_cycles) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.events (event_id, event_name, event_date, location, event_url, event_end_date, event_status, event_tags, last_seen_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: health_incidents; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.health_incidents (incident_id, incident_type, severity, opened_at, last_seen_at, resolved_at, alert_sent_at, details) FROM stdin;
\.


--
-- Data for Name: locks; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.locks (lock_name, holder, acquired_at, expires_at) FROM stdin;
\.


--
-- Data for Name: monitoring_runs; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.monitoring_runs (run_id, started_at, completed_at, status, events_checked, shifts_checked, verified_openings, unverified_shifts, error_count, error_summary, trigger, scheduled_for, full_sweep, requests_made, source_failures, parser_errors, transitions_created, notifications_created) FROM stdin;
66d6a49b-48d8-450d-81ac-7c527964eab2	2026-10-24 03:02:52.517914+00	2026-10-24 03:02:52.517914+00	NOT_AUTHORIZED	0	0	0	0	0	NYRR_COLLECTION_AUTHORIZED is not true; no NYRR requests made (Gate 1)	workflow_dispatch	2026-10-24 03:00:00+00	f	0	0	0	0	0
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.notifications (notification_id, transition_id, recipient_email, delivery_status, attempt_count, last_attempt_at, provider_message_id, created_at, next_attempt_at, idempotency_key, accepted_at, last_error, needs_review) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.schema_migrations (version, applied_at) FROM stdin;
001_initial_schema	2026-10-24 03:02:46.013887+00
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.shifts (shift_id, event_id, role_name, start_time, end_time, is_medical, plus_one_2026, availability_status, classification, registration_url, source_url, verified_at, tags, is_restricted, reason_codes, state_version, alert_armed, last_observed_run_id, last_alerted_at, created_at, updated_at) FROM stdin;
\.


--
-- Name: app_state app_state_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.app_state
    ADD CONSTRAINT app_state_pkey PRIMARY KEY (key);


--
-- Name: availability_transitions availability_transitions_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT availability_transitions_pkey PRIMARY KEY (transition_id);


--
-- Name: email_test_cycles email_test_cycles_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_cycles
    ADD CONSTRAINT email_test_cycles_pkey PRIMARY KEY (cycle_id);


--
-- Name: email_test_cycles email_test_cycles_test_id_cycle_number_key; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_cycles
    ADD CONSTRAINT email_test_cycles_test_id_cycle_number_key UNIQUE (test_id, cycle_number);


--
-- Name: email_test_deliveries email_test_deliveries_cycle_id_recipient_email_key; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_deliveries
    ADD CONSTRAINT email_test_deliveries_cycle_id_recipient_email_key UNIQUE (cycle_id, recipient_email);


--
-- Name: email_test_deliveries email_test_deliveries_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_deliveries
    ADD CONSTRAINT email_test_deliveries_pkey PRIMARY KEY (delivery_id);


--
-- Name: email_test_runs email_test_runs_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_runs
    ADD CONSTRAINT email_test_runs_pkey PRIMARY KEY (test_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (event_id);


--
-- Name: health_incidents health_incidents_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.health_incidents
    ADD CONSTRAINT health_incidents_pkey PRIMARY KEY (incident_id);


--
-- Name: locks locks_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.locks
    ADD CONSTRAINT locks_pkey PRIMARY KEY (lock_name);


--
-- Name: monitoring_runs monitoring_runs_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.monitoring_runs
    ADD CONSTRAINT monitoring_runs_pkey PRIMARY KEY (run_id);


--
-- Name: notifications notifications_idem_uq; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_idem_uq UNIQUE (idempotency_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: notifications notifications_transition_id_recipient_email_key; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_transition_id_recipient_email_key UNIQUE (transition_id, recipient_email);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (shift_id);


--
-- Name: availability_transitions transitions_shift_version_uq; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT transitions_shift_version_uq UNIQUE (shift_id, from_version);


--
-- Name: email_test_one_active_uq; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE UNIQUE INDEX email_test_one_active_uq ON nyrr_monitor.email_test_runs USING btree ((true)) WHERE (status = 'ACTIVE'::text);


--
-- Name: events_event_date_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX events_event_date_idx ON nyrr_monitor.events USING btree (event_date);


--
-- Name: health_incidents_open_uq; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE UNIQUE INDEX health_incidents_open_uq ON nyrr_monitor.health_incidents USING btree (incident_type) WHERE (resolved_at IS NULL);


--
-- Name: monitoring_runs_started_at_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX monitoring_runs_started_at_idx ON nyrr_monitor.monitoring_runs USING btree (started_at);


--
-- Name: notifications_delivery_status_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX notifications_delivery_status_idx ON nyrr_monitor.notifications USING btree (delivery_status);


--
-- Name: notifications_due_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX notifications_due_idx ON nyrr_monitor.notifications USING btree (next_attempt_at) WHERE (delivery_status = ANY (ARRAY['PENDING'::text, 'FAILED_RETRYABLE'::text]));


--
-- Name: shifts_classification_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX shifts_classification_idx ON nyrr_monitor.shifts USING btree (classification);


--
-- Name: shifts_event_id_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX shifts_event_id_idx ON nyrr_monitor.shifts USING btree (event_id);


--
-- Name: shifts_verified_at_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX shifts_verified_at_idx ON nyrr_monitor.shifts USING btree (verified_at);


--
-- Name: transitions_shift_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX transitions_shift_idx ON nyrr_monitor.availability_transitions USING btree (shift_id, detected_at);


--
-- Name: availability_transitions availability_transitions_run_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT availability_transitions_run_id_fkey FOREIGN KEY (run_id) REFERENCES nyrr_monitor.monitoring_runs(run_id);


--
-- Name: availability_transitions availability_transitions_shift_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT availability_transitions_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES nyrr_monitor.shifts(shift_id);


--
-- Name: email_test_cycles email_test_cycles_test_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_cycles
    ADD CONSTRAINT email_test_cycles_test_id_fkey FOREIGN KEY (test_id) REFERENCES nyrr_monitor.email_test_runs(test_id);


--
-- Name: email_test_deliveries email_test_deliveries_cycle_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_deliveries
    ADD CONSTRAINT email_test_deliveries_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES nyrr_monitor.email_test_cycles(cycle_id);


--
-- Name: notifications notifications_transition_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_transition_id_fkey FOREIGN KEY (transition_id) REFERENCES nyrr_monitor.availability_transitions(transition_id);


--
-- Name: shifts shifts_event_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.shifts
    ADD CONSTRAINT shifts_event_id_fkey FOREIGN KEY (event_id) REFERENCES nyrr_monitor.events(event_id);


--
-- Name: app_state; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.app_state ENABLE ROW LEVEL SECURITY;

--
-- Name: availability_transitions; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.availability_transitions ENABLE ROW LEVEL SECURITY;

--
-- Name: email_test_cycles; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.email_test_cycles ENABLE ROW LEVEL SECURITY;

--
-- Name: email_test_deliveries; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.email_test_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: email_test_runs; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.email_test_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: events; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.events ENABLE ROW LEVEL SECURITY;

--
-- Name: health_incidents; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.health_incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: locks; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.locks ENABLE ROW LEVEL SECURITY;

--
-- Name: monitoring_runs; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.monitoring_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: shifts; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.shifts ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict nIhINWGGylMqrcRCxtld05JpTxcFLzne93Jn7mA9lu3qNvN2wAeJiRZ6Z014rKt

