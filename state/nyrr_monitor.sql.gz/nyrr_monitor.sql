--
-- PostgreSQL database dump
--

\restrict z2wYDuEWEDfntOsS57f5GdbuzPp7XJFxBBJYcNDOtFyF0zaYyy8yu5RIKBpv1zZ

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: nyrr_monitor; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA nyrr_monitor;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: app_state; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.app_state (
    key text NOT NULL,
    value jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: availability_transitions; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.availability_transitions (
    transition_id uuid NOT NULL,
    shift_id text NOT NULL,
    previous_classification text,
    new_classification text NOT NULL,
    detected_at timestamp with time zone NOT NULL,
    run_id uuid NOT NULL,
    from_version integer NOT NULL,
    reason_codes text[] DEFAULT '{}'::text[] NOT NULL,
    alert_generated boolean DEFAULT false NOT NULL,
    alert_snapshot jsonb,
    CONSTRAINT transitions_new_chk CHECK ((new_classification = ANY (ARRAY['AVAILABLE_VERIFIED'::text, 'UNAVAILABLE'::text, 'UNVERIFIED'::text]))),
    CONSTRAINT transitions_prev_chk CHECK (((previous_classification IS NULL) OR (previous_classification = ANY (ARRAY['AVAILABLE_VERIFIED'::text, 'UNAVAILABLE'::text, 'UNVERIFIED'::text]))))
);


--
-- Name: email_test_cycles; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.email_test_cycles (
    cycle_id uuid NOT NULL,
    test_id uuid NOT NULL,
    cycle_number integer NOT NULL,
    expected_at timestamp with time zone NOT NULL,
    executed_at timestamp with time zone NOT NULL,
    trigger text NOT NULL,
    CONSTRAINT email_test_cycles_cycle_number_check CHECK (((cycle_number >= 1) AND (cycle_number <= 4)))
);


--
-- Name: email_test_deliveries; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.email_test_deliveries (
    delivery_id uuid NOT NULL,
    cycle_id uuid NOT NULL,
    recipient_email text NOT NULL,
    delivery_status text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    requested_at timestamp with time zone,
    responded_at timestamp with time zone,
    provider_message_id text,
    last_error text,
    CONSTRAINT email_test_deliveries_status_chk CHECK ((delivery_status = ANY (ARRAY['PENDING'::text, 'SENDING'::text, 'ACCEPTED'::text, 'FAILED_RETRYABLE'::text, 'FAILED_PERMANENT'::text])))
);


--
-- Name: email_test_runs; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.email_test_runs (
    test_id uuid NOT NULL,
    activated_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text NOT NULL,
    authorized_by text NOT NULL,
    total_cycles integer DEFAULT 4 NOT NULL,
    CONSTRAINT email_test_status_chk CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'COMPLETED'::text, 'EXPIRED'::text, 'ABORTED'::text])))
);


--
-- Name: events; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.events (
    event_id text NOT NULL,
    event_name text NOT NULL,
    event_date date NOT NULL,
    location text,
    event_url text NOT NULL,
    event_end_date date,
    event_status text,
    event_tags text[] DEFAULT '{}'::text[] NOT NULL,
    last_seen_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: health_incidents; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.health_incidents (
    incident_id uuid NOT NULL,
    incident_type text NOT NULL,
    severity text NOT NULL,
    opened_at timestamp with time zone NOT NULL,
    last_seen_at timestamp with time zone NOT NULL,
    resolved_at timestamp with time zone,
    alert_sent_at timestamp with time zone,
    details text,
    CONSTRAINT health_severity_chk CHECK ((severity = ANY (ARRAY['DEGRADED'::text, 'CRITICAL'::text, 'WARNING'::text])))
);


--
-- Name: locks; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.locks (
    lock_name text NOT NULL,
    holder text NOT NULL,
    acquired_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: monitoring_runs; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.monitoring_runs (
    run_id uuid NOT NULL,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    status text NOT NULL,
    events_checked integer DEFAULT 0 NOT NULL,
    shifts_checked integer DEFAULT 0 NOT NULL,
    verified_openings integer DEFAULT 0 NOT NULL,
    unverified_shifts integer DEFAULT 0 NOT NULL,
    error_count integer DEFAULT 0 NOT NULL,
    error_summary text,
    trigger text,
    scheduled_for timestamp with time zone,
    full_sweep boolean DEFAULT false NOT NULL,
    requests_made integer DEFAULT 0 NOT NULL,
    source_failures integer DEFAULT 0 NOT NULL,
    parser_errors integer DEFAULT 0 NOT NULL,
    transitions_created integer DEFAULT 0 NOT NULL,
    notifications_created integer DEFAULT 0 NOT NULL,
    CONSTRAINT monitoring_runs_status_chk CHECK ((status = ANY (ARRAY['RUNNING'::text, 'SUCCESS'::text, 'PARTIAL'::text, 'FAILED'::text, 'SKIPPED_LOCKED'::text, 'NOT_AUTHORIZED'::text, 'EXPIRED'::text])))
);


--
-- Name: notifications; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.notifications (
    notification_id uuid NOT NULL,
    transition_id uuid NOT NULL,
    recipient_email text NOT NULL,
    delivery_status text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp with time zone,
    provider_message_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key text NOT NULL,
    accepted_at timestamp with time zone,
    last_error text,
    needs_review boolean DEFAULT false NOT NULL,
    CONSTRAINT notifications_status_chk CHECK ((delivery_status = ANY (ARRAY['PENDING'::text, 'SENDING'::text, 'ACCEPTED'::text, 'FAILED_RETRYABLE'::text, 'FAILED_PERMANENT'::text, 'SUPPRESSED'::text])))
);


--
-- Name: schema_migrations; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.schema_migrations (
    version text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: shifts; Type: TABLE; Schema: nyrr_monitor; Owner: -
--

CREATE TABLE nyrr_monitor.shifts (
    shift_id text NOT NULL,
    event_id text NOT NULL,
    role_name text NOT NULL,
    start_time timestamp with time zone,
    end_time timestamp with time zone,
    is_medical boolean,
    plus_one_2026 boolean,
    availability_status text NOT NULL,
    classification text NOT NULL,
    registration_url text,
    source_url text NOT NULL,
    verified_at timestamp with time zone,
    tags text[] DEFAULT '{}'::text[] NOT NULL,
    is_restricted boolean,
    reason_codes text[] DEFAULT '{}'::text[] NOT NULL,
    state_version integer DEFAULT 0 NOT NULL,
    alert_armed boolean DEFAULT true NOT NULL,
    last_observed_run_id uuid,
    last_alerted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT shifts_available_needs_url_chk CHECK (((classification <> 'AVAILABLE_VERIFIED'::text) OR ((registration_url IS NOT NULL) AND (verified_at IS NOT NULL) AND (is_medical = false) AND (plus_one_2026 = true)))),
    CONSTRAINT shifts_classification_chk CHECK ((classification = ANY (ARRAY['AVAILABLE_VERIFIED'::text, 'UNAVAILABLE'::text, 'UNVERIFIED'::text])))
);


--
-- Data for Name: app_state; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.app_state (key, value, updated_at) FROM stdin;
production_activated_at	"2026-10-24T03:09:03.707804+00:00"	2026-10-24 03:09:03.707804+00
last_full_sweep_at	"2026-10-24T16:10:48.642072+00:00"	2026-10-24 16:11:31.094562+00
\.


--
-- Data for Name: availability_transitions; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.availability_transitions (transition_id, shift_id, previous_classification, new_classification, detected_at, run_id, from_version, reason_codes, alert_generated, alert_snapshot) FROM stdin;
2d39ff4c-d16c-46f2-ac7f-8b87433bde86	6ada6a67b0755200012d2c44	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
b68116cd-1cd6-46ad-912e-92cc5b0b9d71	6ada6a67b0755200012d2c46	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
f2edbbd4-340c-4dd4-bc52-7745f700c02c	6ada6a67b0755200012d2c48	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
11e0f12a-bf48-4de7-8a1f-3e805c77e1ec	6ada6a67b0755200012d2c4a	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
8e83de7e-9f52-48e0-ad30-4f9973c1ad09	6ada6a67b0755200012d2c4c	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
f198709b-0ade-46d3-9071-0ce563cf89b2	6ada6a67b0755200012d2c4e	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,RESTRICTED_ROLE}	f	\N
f8a0a313-f6c6-41c2-834d-bbbaea68ee98	6ada6a67b0755200012d2c50	\N	UNAVAILABLE	2026-10-24 03:09:06.178034+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
64d2108e-565f-4b13-8b4b-5f1de5953411	6acdc7f294b2200001cdb118	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
5a98d876-5541-4463-b6e9-f70122eade2d	6acdc7f294b2200001cdb11a	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
68f8f970-8de6-469f-8688-04d497a21bba	6acdc7f294b2200001cdb11c	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
3d3a95ca-a96e-4efa-b003-3f0907a9e780	6acdc7f294b2200001cdb11e	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
66c9416f-6483-4604-b8d2-43020c3d785a	6acdc7f294b2200001cdb120	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
399a2a59-5d74-4f04-bd1e-f846f324869b	6acdc7f294b2200001cdb122	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
ce8eb2e2-058c-436d-9ef3-20ebe3aa8918	6acdc7f294b2200001cdb124	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,RESTRICTED_ROLE}	f	\N
f16fe7bc-698b-4d3b-b1f0-b3cc46069c56	6acdc7f294b2200001cdb126	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
ea1105d3-80b0-4b07-8982-6fc0fa41d66c	6acdc7f294b2200001cdb128	\N	UNAVAILABLE	2026-10-24 03:09:08.100938+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
4fe8318e-733d-4e17-abda-f77fcdd273ef	6ad8dffe54db360001b051c6	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,RESTRICTED_ROLE,REGISTRATION_UNCONFIRMED}	f	\N
9586a8db-d7d8-4374-b492-006e4056075d	6ad8dffe54db360001b051c8	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
472aee7d-9264-4c5d-a998-68a469c65e5f	6ad8dffe54db360001b051ca	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
2cc230fe-b91f-4fde-8684-961b3487018a	6ad8dffe54db360001b051cc	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
6b61c4b5-5d52-4a86-a7ec-c11dba4c0984	6ad8dffe54db360001b051ce	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
7707aa59-752d-46fd-8670-cfbd2de0164b	6ad8dffe54db360001b051d0	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
0bd1e6f3-e237-4c5e-9551-f7af113b0320	6ad8dffe54db360001b051d2	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
eb6c5e4f-b2e6-41b3-be58-2cad55a1f586	6ad8dffe54db360001b051d4	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
e1a623ae-ff34-425d-8470-0342080fc320	6ad8dffe54db360001b051d6	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
91f0957d-3bc7-4c5a-9bd0-02df3dc685b7	6ad8dffe54db360001b051d8	\N	UNAVAILABLE	2026-10-24 03:09:10.117191+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
b2d6d24b-fc26-4de3-8a82-665b60eb6ed3	6adc0d3727bb49000139b3d6	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
a7913528-1fe5-4e4e-868e-aef72424f561	6adc0d3727bb49000139b3d8	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
4517e1cc-aa6d-4715-991d-56be7a4bf6ae	6adc0d3727bb49000139b3da	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
d91091c6-a1f0-4f17-8773-cff585d725c0	6adc0d3727bb49000139b3dc	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
92f8cada-0caa-4007-bbd6-727a1f1b1792	6adc0d3727bb49000139b3de	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
91d1d35d-007a-4330-bd9e-504f73b7b230	6adc0d3727bb49000139b3e0	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
ab262023-0504-4632-a092-ced651a1fce9	6adc0d3727bb49000139b3e2	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
8a23db2c-f4c2-40e5-9840-14db2a3e3b38	6adc0d3727bb49000139b3e4	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
fdab32e4-6d5e-4024-94be-065babc928d8	6adc0d3727bb49000139b3e6	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
00e1fdc0-d973-4d65-a4b1-8fdfe503f47c	6adc0d3727bb49000139b3e8	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
c9f8ecbf-4f71-470e-9ab8-b360260369e6	6adc0d3727bb49000139b3ea	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
58242f62-35a2-4b24-a77e-583f49994aac	6adc0d3727bb49000139b3ec	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
c6c1f15d-90b8-4459-9d14-087c1be53523	6adc0d3727bb49000139b3ee	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
151f5066-e4aa-4e01-b486-761d50ab9512	6adc0d3727bb49000139b3f0	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
dff518cb-6fb6-436e-930d-d16ea653cafb	6adc0d3727bb49000139b3f2	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
341d8570-973c-40fa-b0f2-f61bbdd7170a	6adc0d3727bb49000139b3f4	\N	UNVERIFIED	2026-10-24 03:09:12.237771+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
e7fc8da2-55e9-4c74-9a4b-2f19d2b6e80e	6ad79c5e3fa07f0001af9bd1	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
7bcb24fc-c236-485c-88aa-ae9a6dc375b4	6ad79c5e3fa07f0001af9bd3	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
c539cb24-b491-4738-89c2-eb8e8c27b1fe	6ad79c5e3fa07f0001af9bd5	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
25213e27-1309-4f76-80c5-eab422376c9f	6ad79c5e3fa07f0001af9bd7	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
fe7f8ffc-f31c-43a1-94fe-1e9aaca82930	6ad79c5e3fa07f0001af9bd9	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
c58178fd-d2e6-47d6-8118-c2266d965251	6ad79c5e3fa07f0001af9bdb	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
da4a1cae-28d2-45d8-99c4-49d75f72b75c	6ad79c5e3fa07f0001af9bdd	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,RESTRICTED_ROLE}	f	\N
5f6b9f89-3e06-4a65-8604-edf39fb4e624	6ad79c5e3fa07f0001af9bdf	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
4c94b192-9cf4-40e5-9c71-2f0f0175fa75	6ad79c5e3fa07f0001af9be1	\N	UNAVAILABLE	2026-10-24 03:09:14.082829+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
ba68f8ad-4e25-4023-9b72-eadd37bc8cdc	6adc0e77b22c540001779fec	\N	UNAVAILABLE	2026-10-24 03:09:16.066984+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
b6ad3b12-5d9c-47af-9fe7-a7319a79e8ce	6adc0e77b22c540001779fee	\N	UNAVAILABLE	2026-10-24 03:09:16.066984+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
f7916e5f-6a29-4bc9-8d79-8c1865148bfc	6adc0e77b22c540001779ff0	\N	UNAVAILABLE	2026-10-24 03:09:16.066984+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
d0a651a8-5bef-40dd-9a02-3842ad0dceaa	6adc0e77b22c540001779ff2	\N	UNAVAILABLE	2026-10-24 03:09:16.066984+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
520376ed-5c59-4463-be30-fcc95c8b2af2	6adc0e77b22c540001779ff4	\N	UNAVAILABLE	2026-10-24 03:09:16.066984+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
93101db1-22af-4f76-99ee-430073d9dc40	6ad8523a54db360001b050b8	\N	UNAVAILABLE	2026-10-24 03:09:18.117571+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
4bfa342e-718c-4d9c-addb-364afc6ef14a	6ad8523a54db360001b050ba	\N	UNAVAILABLE	2026-10-24 03:09:18.117571+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
a6752bfc-6f7c-4ee6-bc34-ee27f6bfbd5a	6ad8523a54db360001b050bc	\N	UNAVAILABLE	2026-10-24 03:09:18.117571+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
27ed62e7-1184-4e5c-b8c3-df6c41dd8b96	6adbabf39398e90001e7a9f5	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
d53a5a4b-b5c1-49a0-8125-71c6d0654bcc	6adbabf39398e90001e7a9f7	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
25d56f9e-db7c-4818-a614-0a2c3e26e584	6adbabf39398e90001e7a9f9	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
2b4de990-6203-4309-a9e4-2fa885bb10b5	6adbabf39398e90001e7a9fb	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
d2200275-34f8-4907-84da-af0d4dd31038	6adbabf39398e90001e7a9fd	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
0e05514b-2cbc-487e-88c2-8b43bd185526	6adbabf39398e90001e7a9ff	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
4605e51b-87e2-4310-aaeb-a844674efeb1	6adbabf39398e90001e7aa01	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
e22be0e3-f25f-4f9d-baaf-69b5e3fe8355	6adbabf39398e90001e7aa03	\N	UNAVAILABLE	2026-10-24 03:09:20.119362+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
06ab656c-8d36-4907-999e-9c879e88209e	6ad91836f0c8f2000155d675	\N	UNAVAILABLE	2026-10-24 03:09:22.158372+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
096e0ff0-6757-44ac-9aa7-28967361503a	6adb8236e689900001605e25	\N	UNAVAILABLE	2026-10-24 03:09:24.077128+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
099e76b5-d1cf-432f-b916-ae1bf6bf91ec	6adb8236e689900001605e27	\N	UNAVAILABLE	2026-10-24 03:09:24.077128+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
d9b71db9-3b3f-486f-943c-27ab68abf8ef	6adb8236e689900001605e29	\N	UNAVAILABLE	2026-10-24 03:09:24.077128+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
b8be8f3c-a878-4db2-b570-7635cc4bcc20	6adb8236e689900001605e2b	\N	UNAVAILABLE	2026-10-24 03:09:24.077128+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
ab0d2c21-fd2b-45d5-99d0-cf6977d59b8b	6adbc6e8b22c540001779fb3	\N	UNVERIFIED	2026-10-24 03:09:26.06449+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_UNCONFIRMED}	f	\N
6855c633-4dba-49c1-a545-87ceeb2e5417	6adbc6e8b22c540001779fb5	\N	UNAVAILABLE	2026-10-24 03:09:26.06449+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
2c899e6a-64f9-4d17-b0c1-87640bae9438	6ad79aae4206bf0001466597	\N	UNAVAILABLE	2026-10-24 03:09:30.106101+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
7d25acd4-8b0f-489f-b493-c0d4aea4808e	6ad79aad4206bf0001466595	\N	UNAVAILABLE	2026-10-24 03:09:32.054166+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
8ceb1464-37db-40f3-8d8d-a59155f69d38	6adb9d44480f160001aa8083	\N	UNAVAILABLE	2026-10-24 03:09:34.066231+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
ebb46744-00b3-416e-81fa-b36095409013	6adb9d44480f160001aa8085	\N	UNAVAILABLE	2026-10-24 03:09:34.066231+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
bb07db45-2bfa-4272-9cb8-8b9cc9a1ee55	6adb9d44480f160001aa8087	\N	UNAVAILABLE	2026-10-24 03:09:34.066231+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
e5002055-800c-4ffb-b4a8-cfd5dabb89b8	6ad416c04e014f0001d267cc	\N	UNAVAILABLE	2026-10-24 03:09:36.086523+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
f3796675-c751-4aa7-b716-9ae7cc56fed8	6ad7b6f101b98600012bf686	\N	UNAVAILABLE	2026-10-24 03:09:38.1241+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
beb14518-a5e8-4478-9281-db2de0585eda	6ada9350cd863c0001921407	\N	UNAVAILABLE	2026-10-24 03:09:40.087659+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,REGISTRATION_CLOSED}	f	\N
fc6197b7-d69e-479f-954d-254e268e29a8	6ad7fd97e689900001605853	\N	UNAVAILABLE	2026-10-24 03:09:42.109006+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
e2f5ec4f-41d0-4b77-90b9-a93a5a530409	6adbe4decfd8b50001323e5d	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
adb44516-f5f7-47bd-a637-e2ef654a095b	6adbe4decfd8b50001323e5f	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,SOLD_OUT}	f	\N
bb2ecbbf-6ca7-472a-acea-b84e95a2a069	6adbe4decfd8b50001323e61	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
28bf627e-11c3-42a1-97a6-a833a8e22c94	6adbe4decfd8b50001323e63	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
139b0dad-2751-4c2e-bce8-fff82629b401	6adbe4decfd8b50001323e65	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
4a870570-2287-41a4-a213-f7919760beca	6adbe4decfd8b50001323e67	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
98008ece-d69a-44a1-aec3-76c6f5c27479	6adbe4decfd8b50001323e69	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
82e4aa8c-a67c-44ab-91e6-7b14f7972a66	6adbe4decfd8b50001323e6b	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
dee261e7-bb63-4725-95e8-551e79b84f99	6adbe4decfd8b50001323e6d	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
d0631265-c9f0-43f2-aa5c-4f5d97231225	6adbe4decfd8b50001323e6f	\N	UNAVAILABLE	2026-10-24 03:09:44.12957+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{REGISTRATION_CLOSED}	f	\N
d5c0cecf-6b6c-44d4-8bf0-44e4b213c680	6ad7d4466d8b9600014a2d7e	\N	UNAVAILABLE	2026-10-24 03:09:46.154162+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,SOLD_OUT}	f	\N
6b0d5192-9561-42f6-aa6c-cea9a00a94a5	6ad7d4466d8b9600014a2d80	\N	UNAVAILABLE	2026-10-24 03:09:46.154162+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
07968ffb-0366-43c6-bff6-1af301d737d2	6ad7d4466d8b9600014a2d82	\N	UNAVAILABLE	2026-10-24 03:09:46.154162+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{SOLD_OUT}	f	\N
8c5adf1f-a4bd-49fd-b04b-131101830499	6ad7d4466d8b9600014a2d84	\N	UNAVAILABLE	2026-10-24 03:09:46.154162+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,SOLD_OUT}	f	\N
4bc8ca9e-81e5-4d80-9da1-f4e3cb41b47f	6ad7d4466d8b9600014a2d86	\N	UNAVAILABLE	2026-10-24 03:09:46.154162+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,SOLD_OUT}	f	\N
5e61f707-712a-49df-bae2-6a5509153e57	6ad7d4466d8b9600014a2d88	\N	UNAVAILABLE	2026-10-24 03:09:46.154162+00	9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	0	{NO_PLUS_ONE,SOLD_OUT}	f	\N
4f02e416-d76a-4813-94b7-c89bfa0488bd	6adbc6e8b22c540001779fb3	UNVERIFIED	UNAVAILABLE	2026-10-24 03:11:55.611+00	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	1	{REGISTRATION_CLOSED}	f	\N
3f0dcfea-7308-4688-ab05-a8be4449733e	6adc4577fafa1e0001614386	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
53bd40ba-b95e-473f-a974-9e5f5934c95c	6adc4577fafa1e0001614388	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
c42221cf-cf43-4347-ba40-c37b9e162fdb	6adc4577fafa1e000161438a	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
513c976f-33fb-4d0e-857f-b0041d1dccc4	6adc4577fafa1e000161438c	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
566fac57-3c3c-4360-9b16-e6e73e2890fc	6adc4577fafa1e000161438e	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
a8630388-aa3d-4497-874e-9d7bdcb4e248	6adc4577fafa1e0001614390	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
1b2e0d19-ba68-4665-9704-14585ea5f835	6adc4577fafa1e0001614392	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
1fe92461-4380-4b7f-abab-0675b5d9c680	6adc4577fafa1e0001614394	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
7bf51ad5-51db-4151-8c2e-9c0503391ee8	6adc4577fafa1e0001614396	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
9112ef7c-2549-4b2c-b589-b685c22afb14	6adc4577fafa1e0001614398	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
ab09c3be-71ec-4c70-bc44-b10e07ff7f44	6adc4577fafa1e000161439a	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
3a933b51-6f9c-4073-9006-b1027f2f80aa	6adc4577fafa1e000161439c	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
0a9eaefc-7063-43f8-bea0-627dfd619664	6adc4577fafa1e000161439e	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
b6cef99e-9b51-47e6-94fc-bd9ed3270c0c	6adc4577fafa1e00016143a0	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
fa3b5647-fdfa-4882-b46f-70077b10ef2c	6adc4577fafa1e00016143a2	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
fbe9fc16-eb08-409a-9d24-429dd8d480ce	6adc4577fafa1e00016143a4	\N	UNVERIFIED	2026-10-24 07:52:59.301299+00	feb99a3b-1990-4ac1-a61c-cd414f95af3d	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
0fe2c8b9-e1ff-4701-b790-e6dd104fed79	6adca7e8fafa1e0001614450	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
82b3d5d0-1463-4786-a4c7-1e9202c2be24	6adca7e8fafa1e0001614452	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
e7a12929-d3ab-4566-9ce9-c27622e15f3a	6adca7e8fafa1e0001614454	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
95781634-98cb-4947-9f73-50fa04e4a5e9	6adca7e8fafa1e0001614456	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
aeb30dda-d34e-437c-bdcf-a3d0175c3c0e	6adca7e8fafa1e0001614458	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
9aaf663d-5c11-4c26-bb73-09edf54eb4e6	6adca7e8fafa1e000161445a	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
e1c96b04-5072-4c2b-93e3-b5e6917b402a	6adca7e8fafa1e000161445c	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
43cfecb8-9834-47bd-a2d9-f831259e0a5b	6adca7e8fafa1e000161445e	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
88e3f01e-78d7-4c5b-a9b2-9c84334f32f9	6adca7e8fafa1e0001614460	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
39f92297-4cb3-4a25-a99a-4ded268208fd	6adca7e8fafa1e0001614462	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
517225cb-1112-428c-9003-4af7b22bb934	6adca7e8fafa1e0001614464	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
1847b233-ace9-4f66-b183-7fb418fc5e56	6adca7e8fafa1e0001614466	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
c01c453e-9913-47fb-a69b-bd3b714f6a6e	6adca7e8fafa1e0001614468	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
6d1a9119-4e22-4bff-a1f8-c8851bb4c56a	6adca7e8fafa1e000161446a	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
2224930a-fed1-48d6-bba0-96cd7cb4ee97	6adca7e8fafa1e000161446c	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
038c22d9-082c-461d-a287-2b0480187371	6adca7e8fafa1e000161446e	\N	UNVERIFIED	2026-10-24 16:10:51.129214+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	f	\N
3adecf45-b98f-4ebd-ad51-3dfb6a72430f	6adcd318053f660001eec1ca	\N	UNAVAILABLE	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SOLD_OUT}	f	\N
9e2f4cc3-1290-460f-90cc-d82c611d1bdf	6adcd318053f660001eec1cc	\N	UNAVAILABLE	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SOLD_OUT}	f	\N
2bc9422e-ec91-4d1a-a3a0-6253caf8d24f	6adcd318053f660001eec1ce	\N	UNAVAILABLE	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SOLD_OUT}	f	\N
8ce6be1f-b267-453e-a6be-e52af473e7ac	6adcd318053f660001eec1d0	\N	UNAVAILABLE	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SOLD_OUT}	f	\N
df50aa7e-26d5-462b-b7bd-16317b31a107	6adcd318053f660001eec1d2	\N	UNAVAILABLE	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{SOLD_OUT}	f	\N
f2adca06-81f1-4b2d-ab60-4d6f3cec9816	6adc0e77b22c540001779fec	UNAVAILABLE	UNVERIFIED	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	1	{SHIFT_MISSING}	f	\N
61e4ba99-6b67-4780-bb3d-bc9ae7fc2807	6adc0e77b22c540001779fee	UNAVAILABLE	UNVERIFIED	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	1	{SHIFT_MISSING}	f	\N
e8751199-ca86-4230-8795-ad7460339b65	6adc0e77b22c540001779ff0	UNAVAILABLE	UNVERIFIED	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	1	{SHIFT_MISSING}	f	\N
bd4fb37c-364f-496a-b6ba-d4d14511f3fc	6adc0e77b22c540001779ff2	UNAVAILABLE	UNVERIFIED	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	1	{SHIFT_MISSING}	f	\N
7a0c1aa5-ce86-4332-ba53-f4ba8e3b668a	6adc0e77b22c540001779ff4	UNAVAILABLE	UNVERIFIED	2026-10-24 16:11:01.052266+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	1	{SHIFT_MISSING}	f	\N
3cd5199f-042d-49e5-9ecb-953f01cc8907	6adcd2902076360001701193	\N	UNAVAILABLE	2026-10-24 16:11:15.013489+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	0	{REGISTRATION_CLOSED}	f	\N
867372c9-a9cb-4e2b-84e7-09642435b73d	6ad79aae4206bf0001466597	UNAVAILABLE	UNVERIFIED	2026-10-24 16:11:15.013489+00	eb902cd2-4699-4b4e-8bec-15248e5b54b4	1	{SHIFT_MISSING}	f	\N
\.


--
-- Data for Name: email_test_cycles; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.email_test_cycles (cycle_id, test_id, cycle_number, expected_at, executed_at, trigger) FROM stdin;
\.


--
-- Data for Name: email_test_deliveries; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.email_test_deliveries (delivery_id, cycle_id, recipient_email, delivery_status, attempt_count, requested_at, responded_at, provider_message_id, last_error) FROM stdin;
\.


--
-- Data for Name: email_test_runs; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.email_test_runs (test_id, activated_at, expires_at, completed_at, status, authorized_by, total_cycles) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.events (event_id, event_name, event_date, location, event_url, event_end_date, event_status, event_tags, last_seen_at, created_at, updated_at) FROM stdin;
2026/open-run-volunteers	Open Run - Volunteers	2026-06-01	NYC Metro Area Parks	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2027-03-31	available	{}	2026-10-24 16:10:51.129214+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:10:51.129214+00
2026/pre-marathon-support-volunteers	Pre-Marathon Support - Volunteers	2026-10-17	New York City	https://prod.nyrr.org/races-and-events/2026/pre-marathon-support-volunteers	2026-10-31	sold-out	{"9+1 Credit"}	2026-10-24 16:11:11.002113+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:11.002113+00
2026/tcs-new-york-city-marathon-kids-kickoff-brooklyn-volunteers	TCS New York City Marathon Kids Kickoff, Brooklyn - Volunteers	2026-10-24	Brooklyn - Prospect Park	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-brooklyn-volunteers	\N	sold-out	{"9+1 Credit"}	2026-10-24 16:11:17.047565+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:17.047565+00
2026/tcs-new-york-city-marathon-medical-volunteers	TCS New York City Marathon - Medical Volunteers	2026-11-01	New York City Marathon Medical - Various Locations	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-medical-volunteers	\N	closed	{Medical,"9+1 Credit"}	2026-10-24 16:10:48.642072+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:10:48.642072+00
2026/nyrr-frosty-5k-volunteers	NYRR Frosty 5K - Volunteers	2026-12-12	Prospect Park	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	\N	limited-availability	{"9+1 Credit"}	2026-10-24 16:10:53.046376+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:10:53.046376+00
2026/nyrr-midnight-run-volunteers	NYRR Midnight Run - Volunteers	2026-12-31	Central Park	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	\N	limited-availability	{"9+1 Credit"}	2026-10-24 16:10:55.1253+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:10:55.1253+00
2026/nyrr-ted-corbitt-15k-volunteers	NYRR Ted Corbitt 15K - Volunteers	2026-12-05	Central Park	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	\N	limited-availability	{"9+1 Credit"}	2026-10-24 16:10:57.058811+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:10:57.058811+00
2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Race to Deliver 4M to Benefit God's Love We Deliver - Volunteers	2026-11-22	Central Park	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	\N	limited-availability	{"9+1 Credit"}	2026-10-24 16:10:59.018492+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:10:59.018492+00
2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026 TCS New York City Marathon Expo - Volunteers	2026-10-29	Javits Center	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-31	sold-out	{"9+1 Credit"}	2026-10-24 16:11:01.052266+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:01.052266+00
2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	2026 TCS New York City Marathon Volunteers - Marathon Opening Ceremony	2026-10-30	Central Park - Outside Tavern on the Green	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	\N	sold-out	{"9+1 Credit"}	2026-10-24 16:11:03.109176+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:03.109176+00
2026/abbott-dash-to-the-finish-line-5k-volunteers	Abbott Dash to the Finish Line 5K - Volunteers	2026-10-31	Dag Hammarskjold Plaza	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-31	sold-out	{"9+1 Credit"}	2026-10-24 16:11:05.026178+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:05.026178+00
2026/nyrr-cross-country-series-3-volunteers	NYRR Cross Country Series #3 - Volunteers	2026-11-15	Van Cortlandt Park	https://prod.nyrr.org/races-and-events/2026/nyrr-cross-country-series-3-volunteers	\N	sold-out	{"9+1 Credit"}	2026-10-24 16:11:07.09158+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:07.09158+00
2026/post-marathon-week-volunteers	Post-Marathon Week - Volunteers	2026-11-02	Central Park - Marathon Pavilion	https://prod.nyrr.org/races-and-events/2026/post-marathon-week-volunteers	\N	sold-out	{"9+1 Credit"}	2026-10-24 16:11:09.072273+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:09.072273+00
2026/tcs-new-york-city-marathon-course-volunteers	TCS New York City Marathon - Course Volunteers	2026-11-01	New York	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-course-volunteers	2026-11-01	coming-soon	{"No +1"}	2026-10-24 16:11:13.142377+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:13.142377+00
2026/tcs-new-york-city-marathon-kids-kickoff-bronx-volunteers	TCS New York City Marathon Kids Kickoff, Bronx - Volunteers	2026-10-24	St. Mary's Park	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-bronx-volunteers	\N	closed	{"9+1 Credit"}	2026-10-24 16:11:15.013489+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:15.013489+00
2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	TCS New York City Marathon Kids Kickoff, Central Park - Volunteers	2026-10-25	Central Park	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	2026-10-25	sold-out	{"9+1 Credit"}	2026-10-24 16:11:19.015015+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:19.015015+00
2026/tcs-new-york-city-marathon-kids-kickoff-queens-volunteers	TCS New York City Marathon Kids Kickoff, Queens - Volunteers	2026-10-24	Queens	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-queens-volunteers	\N	sold-out	{"9+1 Credit"}	2026-10-24 16:11:21.048172+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:21.048172+00
2026/tcs-new-york-city-marathon-kids-kickoff-staten-island-volunteers	TCS New York City Marathon Kids Kickoff, Staten Island - Volunteers	2026-10-24	Ocean Breeze Park	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-staten-island-volunteers	2026-10-24	sold-out	{"9+1 Credit"}	2026-10-24 16:11:23.040645+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:23.040645+00
2026/tcs-new-york-city-marathon-post-finish-volunteers	TCS New York City Marathon - Post Finish Volunteers	2026-11-01	Ethical Culture Fieldston School - Manhattan	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-post-finish-volunteers	2026-11-01	closed	{"No +1"}	2026-10-24 16:11:25.007167+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:25.007167+00
2026/tcs-new-york-city-marathon-pre-race-bag-check-volunteers	TCS New York City Marathon Pre-Race Bag Check - Volunteers	2026-10-30	West 69th Street on Central Park West	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-pre-race-bag-check-volunteers	\N	sold-out	{"9+1 Credit"}	2026-10-24 16:11:27.028914+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:27.028914+00
2026/tcs-new-york-city-marathon-start-volunteers	TCS New York City Marathon - Start Volunteers	2026-11-01	Fort Wadsworth, Staten Island	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-11-01	sold-out	{"9+1 Credit"}	2026-10-24 16:11:29.117663+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:29.117663+00
2026/tcs-new-york-city-marathon-transportation-volunteers	TCS New York City Marathon - Transportation Volunteers	2026-11-01	Central Park	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-11-01	sold-out	{"No +1","9+1 Credit"}	2026-10-24 16:11:31.086018+00	2026-10-24 03:09:03.707804+00	2026-10-24 16:11:31.086018+00
\.


--
-- Data for Name: health_incidents; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.health_incidents (incident_id, incident_type, severity, opened_at, last_seen_at, resolved_at, alert_sent_at, details) FROM stdin;
a878a879-84a3-477e-80ca-0221ce10ef96	PARSER_CHANGE	CRITICAL	2026-10-24 03:09:46.170233+00	2026-10-24 03:09:46.170233+00	2026-10-24 03:12:03.701113+00	2026-10-24 03:09:46.170233+00	1 NYRR page(s) did not match the expected structure. No alerts are generated from unparseable pages.
17988b90-a76d-4657-b56b-4ab2b8a3bcc7	MISSED_INTERVALS	DEGRADED	2026-10-24 07:53:39.296229+00	2026-10-24 16:11:31.11758+00	\N	2026-10-24 07:53:39.296229+00	12 consecutive 15-minute intervals had no monitoring run (GitHub Actions schedule delayed or skipped).
\.


--
-- Data for Name: locks; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.locks (lock_name, holder, acquired_at, expires_at) FROM stdin;
\.


--
-- Data for Name: monitoring_runs; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.monitoring_runs (run_id, started_at, completed_at, status, events_checked, shifts_checked, verified_openings, unverified_shifts, error_count, error_summary, trigger, scheduled_for, full_sweep, requests_made, source_failures, parser_errors, transitions_created, notifications_created) FROM stdin;
66d6a49b-48d8-450d-81ac-7c527964eab2	2026-10-24 03:02:52.517914+00	2026-10-24 03:02:52.517914+00	NOT_AUTHORIZED	0	0	0	0	0	NYRR_COLLECTION_AUTHORIZED is not true; no NYRR requests made (Gate 1)	workflow_dispatch	2026-10-24 03:00:00+00	f	0	0	0	0	0
9d7aa9d1-742b-4e37-aeb7-4160f0a50a0a	2026-10-24 03:09:03.707804+00	2026-10-24 03:09:46.169538+00	PARTIAL	20	99	0	17	1	PARSER_ERROR 2026/tcs-new-york-city-marathon-course-volunteers: 2026/tcs-new-york-city-marathon-course-volunteers: registration options container missing	workflow_dispatch	2026-10-24 03:00:00+00	t	22	0	1	99	0
fc7b3f61-ab3d-458b-a37f-9fcb8324f389	2026-10-24 03:11:51.250235+00	2026-10-24 03:12:03.700408+00	SUCCESS	6	53	0	16	0	\N	workflow_dispatch	2026-10-24 03:00:00+00	f	7	0	0	1	0
feb99a3b-1990-4ac1-a61c-cd414f95af3d	2026-10-24 07:52:56.709658+00	2026-10-24 07:53:39.295435+00	SUCCESS	21	99	0	16	0	\N	schedule	2026-10-24 07:45:00+00	t	22	0	0	16	0
0662603f-6631-47ac-bb19-9d83f9adaba4	2026-10-24 12:26:59.901793+00	2026-10-24 12:27:42.368835+00	SUCCESS	21	99	0	16	0	\N	schedule	2026-10-24 12:15:00+00	t	22	0	0	0	0
eb902cd2-4699-4b4e-8bec-15248e5b54b4	2026-10-24 16:10:48.642072+00	2026-10-24 16:11:31.116761+00	SUCCESS	21	99	0	16	0	\N	schedule	2026-10-24 16:00:00+00	t	22	0	0	28	0
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.notifications (notification_id, transition_id, recipient_email, delivery_status, attempt_count, last_attempt_at, provider_message_id, created_at, next_attempt_at, idempotency_key, accepted_at, last_error, needs_review) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.schema_migrations (version, applied_at) FROM stdin;
001_initial_schema	2026-10-24 03:02:46.013887+00
\.


--
-- Data for Name: shifts; Type: TABLE DATA; Schema: nyrr_monitor; Owner: -
--

COPY nyrr_monitor.shifts (shift_id, event_id, role_name, start_time, end_time, is_medical, plus_one_2026, availability_status, classification, registration_url, source_url, verified_at, tags, is_restricted, reason_codes, state_version, alert_armed, last_observed_run_id, last_alerted_at, created_at, updated_at) FROM stdin;
6adc0d3727bb49000139b3d6	2026/open-run-volunteers	Morningside Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=1a1a960d6784271d40a8	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3d8	2026/open-run-volunteers	Marine Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=4600021afcef1cf19831	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3da	2026/open-run-volunteers	Lincoln Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=20ed8d793eb1e2a80ebe	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3dc	2026/open-run-volunteers	Astoria Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=a97653f63212547c3d42	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3de	2026/open-run-volunteers	Canarsie Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=b24f7d593c4fb3ab3190	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6ad8523a54db360001b050b8	2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	Bag Check	2026-10-30 19:15:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	2026-10-24 16:11:03.006349+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:18.117759+00	2026-10-24 16:11:03.109176+00
6ad8523a54db360001b050ba	2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	Grandstand Marshal	2026-10-30 19:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	2026-10-24 16:11:03.006349+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:18.117759+00	2026-10-24 16:11:03.109176+00
6adbabf39398e90001e7a9f5	2026/abbott-dash-to-the-finish-line-5k-volunteers	Post-Race Amenities	2026-10-31 11:30:00+00	2026-10-31 14:45:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6adbabf39398e90001e7a9f7	2026/abbott-dash-to-the-finish-line-5k-volunteers	Walk-Off Marshal	2026-10-31 11:45:00+00	2026-10-31 14:45:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6adbabf39398e90001e7a9f9	2026/abbott-dash-to-the-finish-line-5k-volunteers	Start Corral Marshal	2026-10-31 10:45:00+00	2026-10-31 14:15:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6ad91836f0c8f2000155d675	2026/nyrr-cross-country-series-3-volunteers	Cross Country Assistant	2026-11-15 12:30:00+00	2026-11-15 17:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-cross-country-series-3-volunteers	2026-10-24 16:11:07.023671+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:22.15855+00	2026-10-24 16:11:07.09158+00
6adb8236e689900001605e25	2026/post-marathon-week-volunteers	Central Park Green Team	2026-11-02 14:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/post-marathon-week-volunteers	2026-10-24 16:11:09.004053+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:24.0773+00	2026-10-24 16:11:09.072273+00
6adb8236e689900001605e27	2026/post-marathon-week-volunteers	Marathon Monday Ambassador - RUN CENTER	2026-11-02 13:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/post-marathon-week-volunteers	2026-10-24 16:11:09.004053+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:24.0773+00	2026-10-24 16:11:09.072273+00
6adb8236e689900001605e29	2026/post-marathon-week-volunteers	Post-Marathon Ambassador	2026-11-02 12:30:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/post-marathon-week-volunteers	2026-10-24 16:11:09.004053+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:24.0773+00	2026-10-24 16:11:09.072273+00
6adb8236e689900001605e2b	2026/post-marathon-week-volunteers	Marathon Monday Ambassador - Pavilion	2026-11-02 11:30:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/post-marathon-week-volunteers	2026-10-24 16:11:09.004053+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:24.0773+00	2026-10-24 16:11:09.072273+00
6adbe4decfd8b50001323e5f	2026/tcs-new-york-city-marathon-start-volunteers	START Jump Team	2026-11-01 10:00:00+00	\N	f	f	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{"9+1 Credit"}	f	{NO_PLUS_ONE,SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adc0d3727bb49000139b3e0	2026/open-run-volunteers	Brooklyn Bridge Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=2391b66d6bc6ee923cb3	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3e2	2026/open-run-volunteers	Cunningham Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=8de7e7da3ca30bfd7d0c	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3e4	2026/open-run-volunteers	Shore Road Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=b5bd70e8ee8951121b2d	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3e6	2026/open-run-volunteers	Highland Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=d9b118d6a46369404907	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3e8	2026/open-run-volunteers	Conference House Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=cbffd2c2d1b529d17770	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3ea	2026/open-run-volunteers	St. Mary’s Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=bb7329b604665ee65202	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3ec	2026/open-run-volunteers	Flushing Meadows Corona Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=f0ba4072c43b912d94b4	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3ee	2026/open-run-volunteers	Inwood Hill Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=37ce12471d6a0d270b5f	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3f0	2026/open-run-volunteers	Baisley Pond Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=a08a684cc0e6ca426f9c	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adb9d44480f160001aa8083	2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	Course Marshal	2026-10-25 10:30:00+00	2026-10-25 16:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	2026-10-24 16:11:18.944365+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:34.066438+00	2026-10-24 16:11:19.015015+00
6ad416c04e014f0001d267cc	2026/tcs-new-york-city-marathon-kids-kickoff-queens-volunteers	Youth Event Assistant	2026-10-24 11:00:00+00	2026-10-24 16:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-queens-volunteers	2026-10-24 16:11:20.947725+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:36.086756+00	2026-10-24 16:11:21.048172+00
6ad7b6f101b98600012bf686	2026/tcs-new-york-city-marathon-kids-kickoff-staten-island-volunteers	Youth Event Assistant	2026-10-24 15:00:00+00	2026-10-24 20:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-staten-island-volunteers	2026-10-24 16:11:22.97359+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:38.124297+00	2026-10-24 16:11:23.040645+00
6ada9350cd863c0001921407	2026/tcs-new-york-city-marathon-post-finish-volunteers	FINISH Bag Check	2026-11-01 13:30:00+00	\N	f	f	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-post-finish-volunteers	2026-10-24 16:11:24.941339+00	{"No +1"}	f	{NO_PLUS_ONE,REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:40.087886+00	2026-10-24 16:11:25.007167+00
6ad7fd97e689900001605853	2026/tcs-new-york-city-marathon-pre-race-bag-check-volunteers	Pre-Race Bag Check	2026-10-30 12:30:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-pre-race-bag-check-volunteers	2026-10-24 16:11:26.963492+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:42.109215+00	2026-10-24 16:11:27.028914+00
6adbe4decfd8b50001323e5d	2026/tcs-new-york-city-marathon-start-volunteers	START Corral Marshal - Orange	2026-11-01 11:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6ad7d4466d8b9600014a2d7e	2026/tcs-new-york-city-marathon-transportation-volunteers	Ferry Rider Ambassador - Whitehall Terminal	2026-11-01 09:00:00+00	2026-11-01 15:00:00+00	f	f	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-10-24 16:11:31.016873+00	{"No +1"}	f	{NO_PLUS_ONE,SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:46.154361+00	2026-10-24 16:11:31.086018+00
6adc0d3727bb49000139b3f2	2026/open-run-volunteers	Soundview Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=220bec9657ccee1da5be	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6adc0d3727bb49000139b3f4	2026/open-run-volunteers	Crocheron Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=84773ae3d35714df60a0	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 03:11:53.801279+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	fc7b3f61-ab3d-458b-a37f-9fcb8324f389	\N	2026-10-24 03:09:12.23795+00	2026-10-24 03:11:53.847825+00
6acdc7f294b2200001cdb118	2026/nyrr-midnight-run-volunteers	Post-Race Amenities	2027-01-01 03:45:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6acdc7f294b2200001cdb11a	2026/nyrr-midnight-run-volunteers	Fluid Station South	2027-01-01 03:30:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6ad8dffe54db360001b051d4	2026/nyrr-ted-corbitt-15k-volunteers	Medals Distribution	2026-12-05 11:30:00+00	2026-12-05 17:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad8dffe54db360001b051d6	2026/nyrr-ted-corbitt-15k-volunteers	Course Marshal North	2026-12-05 11:45:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad8dffe54db360001b051d8	2026/nyrr-ted-corbitt-15k-volunteers	Fluid Station South	2026-12-05 11:30:00+00	2026-12-05 17:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad79c5e3fa07f0001af9bd1	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Course Marshal South	2026-11-22 11:45:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6ad79c5e3fa07f0001af9bd5	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Youth Event Assistant	2026-11-22 12:45:00+00	2026-11-22 16:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6ad79c5e3fa07f0001af9bd7	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Course Marshal North	2026-11-22 11:45:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6ad79c5e3fa07f0001af9bdb	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Fluid Station South	2026-11-22 11:30:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6ad79c5e3fa07f0001af9bdd	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Volunteer Leaders and Leaders in Training (NO +1)	2026-11-22 10:00:00+00	\N	f	f	available	UNAVAILABLE	https://register.nyrr.org/?event=76745eea47f712e75d62&option=3d40009ff9613b090383	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{"No +1"}	t	{NO_PLUS_ONE,RESTRICTED_ROLE}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6adbc6e8b22c540001779fb3	2026/pre-marathon-support-volunteers	Training Support	\N	\N	f	t	completed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/pre-marathon-support-volunteers	2026-10-24 16:11:10.936299+00	{9+1}	f	{REGISTRATION_CLOSED}	2	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:26.064693+00	2026-10-24 16:11:11.002113+00
6adbc6e8b22c540001779fb5	2026/pre-marathon-support-volunteers	Expo Bib Support	\N	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/pre-marathon-support-volunteers	2026-10-24 16:11:10.936299+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:26.064693+00	2026-10-24 16:11:11.002113+00
6adc4577fafa1e0001614386	2026/open-run-volunteers	Morningside Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=1a1a960d6784271d40a8	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e0001614388	2026/open-run-volunteers	Marine Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=4600021afcef1cf19831	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e000161438a	2026/open-run-volunteers	Lincoln Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=20ed8d793eb1e2a80ebe	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e000161438c	2026/open-run-volunteers	Canarsie Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=b24f7d593c4fb3ab3190	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e000161438e	2026/open-run-volunteers	Brooklyn Bridge Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=2391b66d6bc6ee923cb3	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6ad8523a54db360001b050bc	2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	Ambassador	2026-10-30 18:30:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-volunteers-marathon-opening-ceremony	2026-10-24 16:11:03.006349+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:18.117759+00	2026-10-24 16:11:03.109176+00
6adbabf39398e90001e7a9fb	2026/abbott-dash-to-the-finish-line-5k-volunteers	NYRR Ambassador	2026-10-31 10:45:00+00	2026-10-31 14:15:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6adb9d44480f160001aa8085	2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	Bag Check	2026-10-25 10:30:00+00	2026-10-25 16:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	2026-10-24 16:11:18.944365+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:34.066438+00	2026-10-24 16:11:19.015015+00
6adb9d44480f160001aa8087	2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	Start Corral Marshal	2026-10-25 11:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-central-park-volunteers	2026-10-24 16:11:18.944365+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:34.066438+00	2026-10-24 16:11:19.015015+00
6adbe4decfd8b50001323e63	2026/tcs-new-york-city-marathon-start-volunteers	START Bus Marshal	2026-11-01 09:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adbe4decfd8b50001323e67	2026/tcs-new-york-city-marathon-start-volunteers	START Green Team	2026-11-01 10:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adbe4decfd8b50001323e69	2026/tcs-new-york-city-marathon-start-volunteers	START Village Amenities - Orange	2026-11-01 11:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6ad7d4466d8b9600014a2d84	2026/tcs-new-york-city-marathon-transportation-volunteers	Ferry Terminal Marshal - Pier 79	2026-11-01 09:00:00+00	2026-11-01 15:00:00+00	f	f	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-10-24 16:11:31.016873+00	{"No +1"}	f	{NO_PLUS_ONE,SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:46.154361+00	2026-10-24 16:11:31.086018+00
6ad7d4466d8b9600014a2d86	2026/tcs-new-york-city-marathon-transportation-volunteers	Bus Ambassador - Midtown Manhattan Buses	2026-11-01 08:30:00+00	2026-11-01 13:00:00+00	f	f	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-10-24 16:11:31.016873+00	{"No +1"}	f	{NO_PLUS_ONE,SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:46.154361+00	2026-10-24 16:11:31.086018+00
6ad7d4466d8b9600014a2d88	2026/tcs-new-york-city-marathon-transportation-volunteers	Ferry Terminal Marshal - Whitehall Terminal	2026-11-01 09:00:00+00	2026-11-01 15:00:00+00	f	f	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-10-24 16:11:31.016873+00	{"No +1"}	f	{NO_PLUS_ONE,SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:46.154361+00	2026-10-24 16:11:31.086018+00
6adc4577fafa1e0001614390	2026/open-run-volunteers	Cunningham Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=8de7e7da3ca30bfd7d0c	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e0001614392	2026/open-run-volunteers	Shore Road Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=b5bd70e8ee8951121b2d	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e0001614394	2026/open-run-volunteers	Highland Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=d9b118d6a46369404907	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e0001614396	2026/open-run-volunteers	Baisley Pond Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=a08a684cc0e6ca426f9c	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e0001614398	2026/open-run-volunteers	Conference House Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=cbffd2c2d1b529d17770	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e000161439a	2026/open-run-volunteers	St. Mary’s Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=bb7329b604665ee65202	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e000161439c	2026/open-run-volunteers	Flushing Meadows Corona Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=f0ba4072c43b912d94b4	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e000161439e	2026/open-run-volunteers	Inwood Hill Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=37ce12471d6a0d270b5f	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e00016143a0	2026/open-run-volunteers	Crocheron Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=84773ae3d35714df60a0	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e00016143a2	2026/open-run-volunteers	Soundview Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=220bec9657ccee1da5be	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6adc4577fafa1e00016143a4	2026/open-run-volunteers	Astoria Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=a97653f63212547c3d42	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 12:27:02.408448+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 07:52:59.301533+00	2026-10-24 12:27:02.500753+00
6acdc7f294b2200001cdb124	2026/nyrr-midnight-run-volunteers	Volunteer Leaders and Leaders in Training (NO +1)	2027-01-01 02:30:00+00	2027-01-01 07:00:00+00	f	f	available	UNAVAILABLE	https://register.nyrr.org/?event=1a3d8cfe041851d12a62&option=b7545011fd6c547dc382	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{"No +1"}	t	{NO_PLUS_ONE,RESTRICTED_ROLE}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6acdc7f294b2200001cdb128	2026/nyrr-midnight-run-volunteers	Start and Finish	2027-01-01 03:15:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6ad8dffe54db360001b051c6	2026/nyrr-ted-corbitt-15k-volunteers	Volunteer Leaders and Leaders in Training (NO +1)	2026-12-05 10:00:00+00	\N	f	f	near-capacity	UNAVAILABLE	https://register.nyrr.org/?event=ac5a6d9cfd5d470bc018&option=19eeb8d039fdb7311de4	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{"No +1"}	t	{NO_PLUS_ONE,RESTRICTED_ROLE}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6adca7e8fafa1e0001614450	2026/open-run-volunteers	Morningside Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=1a1a960d6784271d40a8	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614452	2026/open-run-volunteers	Lincoln Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=20ed8d793eb1e2a80ebe	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6ad8dffe54db360001b051c8	2026/nyrr-ted-corbitt-15k-volunteers	NYRR Ambassador	2026-12-05 11:00:00+00	2026-12-05 17:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad8dffe54db360001b051ca	2026/nyrr-ted-corbitt-15k-volunteers	Course Marshal South	2026-12-05 11:45:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad8dffe54db360001b051cc	2026/nyrr-ted-corbitt-15k-volunteers	Bag Check	2026-12-05 11:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad79c5e3fa07f0001af9bd9	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Bag Check	2026-11-22 11:00:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6adbabf39398e90001e7a9fd	2026/abbott-dash-to-the-finish-line-5k-volunteers	Course Marshal - Midtown	2026-10-31 11:30:00+00	2026-10-31 14:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6adbabf39398e90001e7a9ff	2026/abbott-dash-to-the-finish-line-5k-volunteers	Fluid Station	2026-10-31 11:00:00+00	2026-10-31 14:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6adbabf39398e90001e7aa01	2026/abbott-dash-to-the-finish-line-5k-volunteers	Course Marshal - Central Park and Midtown North	2026-10-31 11:30:00+00	2026-10-31 14:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6adbabf39398e90001e7aa03	2026/abbott-dash-to-the-finish-line-5k-volunteers	Bag Check	2026-10-31 10:30:00+00	2026-10-31 14:45:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/abbott-dash-to-the-finish-line-5k-volunteers	2026-10-24 16:11:04.955542+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:20.119548+00	2026-10-24 16:11:05.026178+00
6ad79aae4206bf0001466597	2026/tcs-new-york-city-marathon-kids-kickoff-bronx-volunteers	Youth Event Assistant	2026-10-24 15:00:00+00	2026-10-24 20:00:00+00	f	t	sold-out	UNVERIFIED	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-bronx-volunteers	2026-10-24 12:27:26.389913+00	{9+1}	f	{SHIFT_MISSING}	2	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 03:09:30.106293+00	2026-10-24 16:11:15.013489+00
6adbe4decfd8b50001323e61	2026/tcs-new-york-city-marathon-start-volunteers	START Village Amenities - Blue	2026-11-01 11:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adbe4decfd8b50001323e65	2026/tcs-new-york-city-marathon-start-volunteers	START VIP Hospitality	2026-11-01 09:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adbe4decfd8b50001323e6d	2026/tcs-new-york-city-marathon-start-volunteers	START Village Amenities - Silver Charity	2026-11-01 10:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adbe4decfd8b50001323e6f	2026/tcs-new-york-city-marathon-start-volunteers	START NYRR Ambassadors	2026-11-01 10:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6adca7e8fafa1e0001614454	2026/open-run-volunteers	Canarsie Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=b24f7d593c4fb3ab3190	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614456	2026/open-run-volunteers	Brooklyn Bridge Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=2391b66d6bc6ee923cb3	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614458	2026/open-run-volunteers	Cunningham Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=8de7e7da3ca30bfd7d0c	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e000161445a	2026/open-run-volunteers	Shore Road Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=b5bd70e8ee8951121b2d	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e000161445c	2026/open-run-volunteers	Highland Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=d9b118d6a46369404907	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e000161445e	2026/open-run-volunteers	Marine Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=4600021afcef1cf19831	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614460	2026/open-run-volunteers	Conference House Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=cbffd2c2d1b529d17770	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614462	2026/open-run-volunteers	St. Mary’s Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=bb7329b604665ee65202	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614464	2026/open-run-volunteers	Baisley Pond Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=a08a684cc0e6ca426f9c	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614466	2026/open-run-volunteers	Crocheron Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=84773ae3d35714df60a0	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e0001614468	2026/open-run-volunteers	Flushing Meadows Corona Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=f0ba4072c43b912d94b4	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e000161446a	2026/open-run-volunteers	Inwood Hill Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=37ce12471d6a0d270b5f	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e000161446c	2026/open-run-volunteers	Soundview Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=220bec9657ccee1da5be	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6adca7e8fafa1e000161446e	2026/open-run-volunteers	Astoria Park	\N	\N	\N	\N	available	UNVERIFIED	https://register.nyrr.org/?event=e91a00cb72452bdfa58b&option=a97653f63212547c3d42	https://prod.nyrr.org/races-and-events/2026/open-run-volunteers	2026-10-24 16:10:51.035679+00	{}	f	{SHIFT_DATE_UNCONFIRMED,MEDICAL_UNCONFIRMED,PLUS_ONE_UNCONFIRMED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:10:51.129471+00	2026-10-24 16:10:51.129214+00
6ada6a67b0755200012d2c44	2026/nyrr-frosty-5k-volunteers	Start and Finish	2026-12-12 11:15:00+00	2026-12-12 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6ada6a67b0755200012d2c46	2026/nyrr-frosty-5k-volunteers	Post-Race Amenities	2026-12-12 11:45:00+00	2026-12-12 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6ada6a67b0755200012d2c48	2026/nyrr-frosty-5k-volunteers	Fluid Station	2026-12-12 11:30:00+00	2026-12-12 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6ada6a67b0755200012d2c4a	2026/nyrr-frosty-5k-volunteers	Course Marshal	2026-12-12 11:45:00+00	2026-12-12 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6ada6a67b0755200012d2c4c	2026/nyrr-frosty-5k-volunteers	Bag Check	2026-12-12 11:00:00+00	2026-12-12 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6ada6a67b0755200012d2c4e	2026/nyrr-frosty-5k-volunteers	Volunteer Leaders and Leaders in Training (NO +1)	2026-12-12 05:00:00+00	\N	f	f	available	UNAVAILABLE	https://register.nyrr.org/?event=83d453a5d826700b9e48&option=5b8f008c6592ca18ae4b	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{"No +1"}	t	{NO_PLUS_ONE,RESTRICTED_ROLE}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6ada6a67b0755200012d2c50	2026/nyrr-frosty-5k-volunteers	NYRR Ambassador	2026-12-12 11:00:00+00	2026-12-12 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-frosty-5k-volunteers	2026-10-24 16:10:52.973586+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:06.178225+00	2026-10-24 16:10:53.046376+00
6acdc7f294b2200001cdb11c	2026/nyrr-midnight-run-volunteers	Bag Check	2027-01-01 03:00:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6acdc7f294b2200001cdb11e	2026/nyrr-midnight-run-volunteers	Course Marshal South	2027-01-01 03:45:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6acdc7f294b2200001cdb120	2026/nyrr-midnight-run-volunteers	Fluid Station North	2027-01-01 03:30:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6acdc7f294b2200001cdb122	2026/nyrr-midnight-run-volunteers	Course Marshal North	2027-01-01 03:45:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6acdc7f294b2200001cdb126	2026/nyrr-midnight-run-volunteers	NYRR Ambassador	2027-01-01 03:00:00+00	2027-01-01 07:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-midnight-run-volunteers	2026-10-24 16:10:55.04923+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:08.101136+00	2026-10-24 16:10:55.1253+00
6ad8dffe54db360001b051ce	2026/nyrr-ted-corbitt-15k-volunteers	Start and Finish	2026-12-05 11:15:00+00	2026-12-05 17:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad8dffe54db360001b051d0	2026/nyrr-ted-corbitt-15k-volunteers	Post-Race Amenities	2026-12-05 11:45:00+00	2026-12-05 17:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad8dffe54db360001b051d2	2026/nyrr-ted-corbitt-15k-volunteers	Fluid Station North	2026-12-05 11:30:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/nyrr-ted-corbitt-15k-volunteers	2026-10-24 16:10:56.983773+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:10.117367+00	2026-10-24 16:10:57.058811+00
6ad79c5e3fa07f0001af9bd3	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	NYRR Ambassador	2026-11-22 11:00:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6ad79c5e3fa07f0001af9bdf	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Fluid Station North	2026-11-22 11:30:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6ad79c5e3fa07f0001af9be1	2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	Start and Finish	2026-11-22 11:15:00+00	2026-11-22 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/race-to-deliver-4m-to-benefit-gods-love-we-deliver-volunteers	2026-10-24 16:10:58.942758+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:14.083004+00	2026-10-24 16:10:59.018492+00
6adcd318053f660001eec1ca	2026/2026-tcs-new-york-city-marathon-expo-volunteers	Volunteer Support	\N	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 16:11:00.981413+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:11:01.052437+00	2026-10-24 16:11:01.052266+00
6adcd318053f660001eec1cc	2026/2026-tcs-new-york-city-marathon-expo-volunteers	T-Shirt Distribution	\N	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 16:11:00.981413+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:11:01.052437+00	2026-10-24 16:11:01.052266+00
6adcd318053f660001eec1ce	2026/2026-tcs-new-york-city-marathon-expo-volunteers	Bib Pick-Up	\N	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 16:11:00.981413+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:11:01.052437+00	2026-10-24 16:11:01.052266+00
6adcd318053f660001eec1d0	2026/2026-tcs-new-york-city-marathon-expo-volunteers	International Tour Operator (ITO) Support	\N	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 16:11:00.981413+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:11:01.052437+00	2026-10-24 16:11:01.052266+00
6adcd318053f660001eec1d2	2026/2026-tcs-new-york-city-marathon-expo-volunteers	Ambassador	\N	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 16:11:00.981413+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:11:01.052437+00	2026-10-24 16:11:01.052266+00
6adc0e77b22c540001779fec	2026/2026-tcs-new-york-city-marathon-expo-volunteers	T-Shirt Distribution	\N	\N	f	t	sold-out	UNVERIFIED	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 12:27:12.329456+00	{9+1}	f	{SHIFT_MISSING}	2	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 03:09:16.067163+00	2026-10-24 16:11:01.052266+00
6adc0e77b22c540001779fee	2026/2026-tcs-new-york-city-marathon-expo-volunteers	Volunteer Support	\N	\N	f	t	sold-out	UNVERIFIED	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 12:27:12.329456+00	{9+1}	f	{SHIFT_MISSING}	2	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 03:09:16.067163+00	2026-10-24 16:11:01.052266+00
6adc0e77b22c540001779ff0	2026/2026-tcs-new-york-city-marathon-expo-volunteers	Bib Pick-Up	\N	\N	f	t	sold-out	UNVERIFIED	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 12:27:12.329456+00	{9+1}	f	{SHIFT_MISSING}	2	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 03:09:16.067163+00	2026-10-24 16:11:01.052266+00
6adc0e77b22c540001779ff2	2026/2026-tcs-new-york-city-marathon-expo-volunteers	International Tour Operator (ITO) Support	\N	\N	f	t	sold-out	UNVERIFIED	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 12:27:12.329456+00	{9+1}	f	{SHIFT_MISSING}	2	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 03:09:16.067163+00	2026-10-24 16:11:01.052266+00
6adc0e77b22c540001779ff4	2026/2026-tcs-new-york-city-marathon-expo-volunteers	Ambassador	\N	\N	f	t	sold-out	UNVERIFIED	\N	https://prod.nyrr.org/races-and-events/2026/2026-tcs-new-york-city-marathon-expo-volunteers	2026-10-24 12:27:12.329456+00	{9+1}	f	{SHIFT_MISSING}	2	t	0662603f-6631-47ac-bb19-9d83f9adaba4	\N	2026-10-24 03:09:16.067163+00	2026-10-24 16:11:01.052266+00
6adcd2902076360001701193	2026/tcs-new-york-city-marathon-kids-kickoff-bronx-volunteers	Youth Event Assistant	2026-10-24 15:00:00+00	2026-10-24 20:00:00+00	f	t	completed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-bronx-volunteers	2026-10-24 16:11:14.947171+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 16:11:15.01368+00	2026-10-24 16:11:15.013489+00
6ad79aad4206bf0001466595	2026/tcs-new-york-city-marathon-kids-kickoff-brooklyn-volunteers	Youth Event Assistant	2026-10-24 11:00:00+00	\N	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-kids-kickoff-brooklyn-volunteers	2026-10-24 16:11:16.982529+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:32.054368+00	2026-10-24 16:11:17.047565+00
6adbe4decfd8b50001323e6b	2026/tcs-new-york-city-marathon-start-volunteers	START Bridge Gate Marshal (Background Check REQUIRED)	2026-11-01 09:00:00+00	\N	f	t	registration-closed	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-start-volunteers	2026-10-24 16:11:29.04331+00	{9+1}	f	{REGISTRATION_CLOSED}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:44.129767+00	2026-10-24 16:11:29.117663+00
6ad7d4466d8b9600014a2d80	2026/tcs-new-york-city-marathon-transportation-volunteers	Bus Ambassador - St. George Terminal	2026-11-01 10:00:00+00	2026-11-01 16:00:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-10-24 16:11:31.016873+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:46.154361+00	2026-10-24 16:11:31.086018+00
6ad7d4466d8b9600014a2d82	2026/tcs-new-york-city-marathon-transportation-volunteers	Bus Ambassador - Homeport Ferry	2026-11-01 09:00:00+00	2026-11-01 15:30:00+00	f	t	sold-out	UNAVAILABLE	\N	https://prod.nyrr.org/races-and-events/2026/tcs-new-york-city-marathon-transportation-volunteers	2026-10-24 16:11:31.016873+00	{9+1}	f	{SOLD_OUT}	1	t	eb902cd2-4699-4b4e-8bec-15248e5b54b4	\N	2026-10-24 03:09:46.154361+00	2026-10-24 16:11:31.086018+00
\.


--
-- Name: app_state app_state_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.app_state
    ADD CONSTRAINT app_state_pkey PRIMARY KEY (key);


--
-- Name: availability_transitions availability_transitions_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT availability_transitions_pkey PRIMARY KEY (transition_id);


--
-- Name: email_test_cycles email_test_cycles_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_cycles
    ADD CONSTRAINT email_test_cycles_pkey PRIMARY KEY (cycle_id);


--
-- Name: email_test_cycles email_test_cycles_test_id_cycle_number_key; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_cycles
    ADD CONSTRAINT email_test_cycles_test_id_cycle_number_key UNIQUE (test_id, cycle_number);


--
-- Name: email_test_deliveries email_test_deliveries_cycle_id_recipient_email_key; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_deliveries
    ADD CONSTRAINT email_test_deliveries_cycle_id_recipient_email_key UNIQUE (cycle_id, recipient_email);


--
-- Name: email_test_deliveries email_test_deliveries_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_deliveries
    ADD CONSTRAINT email_test_deliveries_pkey PRIMARY KEY (delivery_id);


--
-- Name: email_test_runs email_test_runs_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_runs
    ADD CONSTRAINT email_test_runs_pkey PRIMARY KEY (test_id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (event_id);


--
-- Name: health_incidents health_incidents_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.health_incidents
    ADD CONSTRAINT health_incidents_pkey PRIMARY KEY (incident_id);


--
-- Name: locks locks_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.locks
    ADD CONSTRAINT locks_pkey PRIMARY KEY (lock_name);


--
-- Name: monitoring_runs monitoring_runs_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.monitoring_runs
    ADD CONSTRAINT monitoring_runs_pkey PRIMARY KEY (run_id);


--
-- Name: notifications notifications_idem_uq; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_idem_uq UNIQUE (idempotency_key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: notifications notifications_transition_id_recipient_email_key; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_transition_id_recipient_email_key UNIQUE (transition_id, recipient_email);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: shifts shifts_pkey; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.shifts
    ADD CONSTRAINT shifts_pkey PRIMARY KEY (shift_id);


--
-- Name: availability_transitions transitions_shift_version_uq; Type: CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT transitions_shift_version_uq UNIQUE (shift_id, from_version);


--
-- Name: email_test_one_active_uq; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE UNIQUE INDEX email_test_one_active_uq ON nyrr_monitor.email_test_runs USING btree ((true)) WHERE (status = 'ACTIVE'::text);


--
-- Name: events_event_date_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX events_event_date_idx ON nyrr_monitor.events USING btree (event_date);


--
-- Name: health_incidents_open_uq; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE UNIQUE INDEX health_incidents_open_uq ON nyrr_monitor.health_incidents USING btree (incident_type) WHERE (resolved_at IS NULL);


--
-- Name: monitoring_runs_started_at_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX monitoring_runs_started_at_idx ON nyrr_monitor.monitoring_runs USING btree (started_at);


--
-- Name: notifications_delivery_status_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX notifications_delivery_status_idx ON nyrr_monitor.notifications USING btree (delivery_status);


--
-- Name: notifications_due_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX notifications_due_idx ON nyrr_monitor.notifications USING btree (next_attempt_at) WHERE (delivery_status = ANY (ARRAY['PENDING'::text, 'FAILED_RETRYABLE'::text]));


--
-- Name: shifts_classification_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX shifts_classification_idx ON nyrr_monitor.shifts USING btree (classification);


--
-- Name: shifts_event_id_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX shifts_event_id_idx ON nyrr_monitor.shifts USING btree (event_id);


--
-- Name: shifts_verified_at_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX shifts_verified_at_idx ON nyrr_monitor.shifts USING btree (verified_at);


--
-- Name: transitions_shift_idx; Type: INDEX; Schema: nyrr_monitor; Owner: -
--

CREATE INDEX transitions_shift_idx ON nyrr_monitor.availability_transitions USING btree (shift_id, detected_at);


--
-- Name: availability_transitions availability_transitions_run_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT availability_transitions_run_id_fkey FOREIGN KEY (run_id) REFERENCES nyrr_monitor.monitoring_runs(run_id);


--
-- Name: availability_transitions availability_transitions_shift_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.availability_transitions
    ADD CONSTRAINT availability_transitions_shift_id_fkey FOREIGN KEY (shift_id) REFERENCES nyrr_monitor.shifts(shift_id);


--
-- Name: email_test_cycles email_test_cycles_test_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_cycles
    ADD CONSTRAINT email_test_cycles_test_id_fkey FOREIGN KEY (test_id) REFERENCES nyrr_monitor.email_test_runs(test_id);


--
-- Name: email_test_deliveries email_test_deliveries_cycle_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.email_test_deliveries
    ADD CONSTRAINT email_test_deliveries_cycle_id_fkey FOREIGN KEY (cycle_id) REFERENCES nyrr_monitor.email_test_cycles(cycle_id);


--
-- Name: notifications notifications_transition_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.notifications
    ADD CONSTRAINT notifications_transition_id_fkey FOREIGN KEY (transition_id) REFERENCES nyrr_monitor.availability_transitions(transition_id);


--
-- Name: shifts shifts_event_id_fkey; Type: FK CONSTRAINT; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE ONLY nyrr_monitor.shifts
    ADD CONSTRAINT shifts_event_id_fkey FOREIGN KEY (event_id) REFERENCES nyrr_monitor.events(event_id);


--
-- Name: app_state; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.app_state ENABLE ROW LEVEL SECURITY;

--
-- Name: availability_transitions; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.availability_transitions ENABLE ROW LEVEL SECURITY;

--
-- Name: email_test_cycles; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.email_test_cycles ENABLE ROW LEVEL SECURITY;

--
-- Name: email_test_deliveries; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.email_test_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: email_test_runs; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.email_test_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: events; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.events ENABLE ROW LEVEL SECURITY;

--
-- Name: health_incidents; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.health_incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: locks; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.locks ENABLE ROW LEVEL SECURITY;

--
-- Name: monitoring_runs; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.monitoring_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: shifts; Type: ROW SECURITY; Schema: nyrr_monitor; Owner: -
--

ALTER TABLE nyrr_monitor.shifts ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict z2wYDuEWEDfntOsS57f5GdbuzPp7XJFxBBJYcNDOtFyF0zaYyy8yu5RIKBpv1zZ

